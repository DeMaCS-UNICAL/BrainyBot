# Generated from DLV2Lexer.g4 by ANTLR 4.7
# encoding: utf-8
from __future__ import print_function
from antlr4 import *
from io import StringIO
import sys


def serializedATN():
    with StringIO() as buf:
        buf.write(u"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\2")
        buf.write(u"\22\u0084\b\1\b\1\b\1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5")
        buf.write(u"\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4")
        buf.write(u"\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21")
        buf.write(u"\4\22\t\22\4\23\t\23\4\24\t\24\3\2\3\2\3\2\3\2\3\3\3")
        buf.write(u"\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\4\6\4=\n")
        buf.write(u"\4\r\4\16\4>\3\4\3\4\3\5\3\5\5\5E\n\5\3\5\3\5\3\6\3\6")
        buf.write(u"\3\7\3\7\3\b\3\b\3\b\3\b\3\t\3\t\3\t\3\t\3\n\3\n\3\13")
        buf.write(u"\3\13\3\f\3\f\7\f[\n\f\f\f\16\f^\13\f\3\r\3\r\3\r\3\r")
        buf.write(u"\3\16\3\16\7\16f\n\16\f\16\16\16i\13\16\3\16\3\16\3\17")
        buf.write(u"\3\17\3\20\3\20\3\21\3\21\5\21s\n\21\3\21\3\21\3\22\3")
        buf.write(u"\22\3\22\7\22z\n\22\f\22\16\22}\13\22\5\22\177\n\22\3")
        buf.write(u"\23\3\23\3\24\3\24\3>\2\25\5\3\7\4\t\5\13\6\r\7\17\b")
        buf.write(u"\21\t\23\n\25\13\27\f\31\r\33\16\35\17\37\20!\21#\22")
        buf.write(u"%\2\'\2)\2\5\2\3\4\t\4\2C\\c|\6\2\62;C\\aac|\3\2$$\3")
        buf.write(u"\2\63;\3\2\62;\4\2\f\f\17\17\4\2\13\13\"\"\2\u0085\2")
        buf.write(u"\5\3\2\2\2\2\7\3\2\2\2\2\t\3\2\2\2\2\13\3\2\2\2\3\r\3")
        buf.write(u"\2\2\2\3\17\3\2\2\2\3\21\3\2\2\2\3\23\3\2\2\2\4\25\3")
        buf.write(u"\2\2\2\4\27\3\2\2\2\4\31\3\2\2\2\4\33\3\2\2\2\4\35\3")
        buf.write(u"\2\2\2\4\37\3\2\2\2\4!\3\2\2\2\4#\3\2\2\2\5+\3\2\2\2")
        buf.write(u"\7/\3\2\2\2\t<\3\2\2\2\13D\3\2\2\2\rH\3\2\2\2\17J\3\2")
        buf.write(u"\2\2\21L\3\2\2\2\23P\3\2\2\2\25T\3\2\2\2\27V\3\2\2\2")
        buf.write(u"\31X\3\2\2\2\33_\3\2\2\2\35c\3\2\2\2\37l\3\2\2\2!n\3")
        buf.write(u"\2\2\2#r\3\2\2\2%~\3\2\2\2\'\u0080\3\2\2\2)\u0082\3\2")
        buf.write(u"\2\2+,\7}\2\2,-\3\2\2\2-.\b\2\2\2.\6\3\2\2\2/\60\7E\2")
        buf.write(u"\2\60\61\7Q\2\2\61\62\7U\2\2\62\63\7V\2\2\63\64\7\"\2")
        buf.write(u"\2\64\65\3\2\2\2\65\66\5%\22\2\66\67\7B\2\2\678\5%\22")
        buf.write(u"\289\3\2\2\29:\b\3\3\2:\b\3\2\2\2;=\13\2\2\2<;\3\2\2")
        buf.write(u"\2=>\3\2\2\2>?\3\2\2\2><\3\2\2\2?@\3\2\2\2@A\b\4\4\2")
        buf.write(u"A\n\3\2\2\2BE\5\'\23\2CE\5)\24\2DB\3\2\2\2DC\3\2\2\2")
        buf.write(u"EF\3\2\2\2FG\b\5\4\2G\f\3\2\2\2HI\7B\2\2I\16\3\2\2\2")
        buf.write(u"JK\5%\22\2K\20\3\2\2\2LM\5\'\23\2MN\3\2\2\2NO\b\b\5\2")
        buf.write(u"O\22\3\2\2\2PQ\5)\24\2QR\3\2\2\2RS\b\t\4\2S\24\3\2\2")
        buf.write(u"\2TU\7.\2\2U\26\3\2\2\2VW\5%\22\2W\30\3\2\2\2X\\\t\2")
        buf.write(u"\2\2Y[\t\3\2\2ZY\3\2\2\2[^\3\2\2\2\\Z\3\2\2\2\\]\3\2")
        buf.write(u"\2\2]\32\3\2\2\2^\\\3\2\2\2_`\7\177\2\2`a\3\2\2\2ab\b")
        buf.write(u"\r\5\2b\34\3\2\2\2cg\7$\2\2df\n\4\2\2ed\3\2\2\2fi\3\2")
        buf.write(u"\2\2ge\3\2\2\2gh\3\2\2\2hj\3\2\2\2ig\3\2\2\2jk\7$\2\2")
        buf.write(u"k\36\3\2\2\2lm\7*\2\2m \3\2\2\2no\7+\2\2o\"\3\2\2\2p")
        buf.write(u"s\5)\24\2qs\5\'\23\2rp\3\2\2\2rq\3\2\2\2st\3\2\2\2tu")
        buf.write(u"\b\21\4\2u$\3\2\2\2v\177\7\62\2\2w{\t\5\2\2xz\t\6\2\2")
        buf.write(u"yx\3\2\2\2z}\3\2\2\2{y\3\2\2\2{|\3\2\2\2|\177\3\2\2\2")
        buf.write(u"}{\3\2\2\2~v\3\2\2\2~w\3\2\2\2\177&\3\2\2\2\u0080\u0081")
        buf.write(u"\t\7\2\2\u0081(\3\2\2\2\u0082\u0083\t\b\2\2\u0083*\3")
        buf.write(u"\2\2\2\f\2\3\4>D\\gr{~\6\4\4\2\4\3\2\b\2\2\4\2\2")
        return buf.getvalue()


class DLV2Lexer(Lexer):

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    COST = 1
    MODEL = 2

    START = 1
    COST_LABEL = 2
    ANY = 3
    IGNORE = 4
    AT = 5
    INTEGER = 6
    NEW_LINE = 7
    BLANK_SPACE = 8
    COMMA = 9
    INTEGER_CONSTANT = 10
    IDENTIFIER = 11
    MODEL_END = 12
    STRING_CONSTANT = 13
    TERMS_BEGIN = 14
    TERMS_END = 15
    WHITE_SPACE = 16

    channelNames = [ u"DEFAULT_TOKEN_CHANNEL", u"HIDDEN" ]

    modeNames = [ u"DEFAULT_MODE", u"COST", u"MODEL" ]

    literalNames = [ u"<INVALID>",
            u"'{'", u"'@'", u"','", u"'}'", u"'('", u"')'" ]

    symbolicNames = [ u"<INVALID>",
            u"START", u"COST_LABEL", u"ANY", u"IGNORE", u"AT", u"INTEGER", 
            u"NEW_LINE", u"BLANK_SPACE", u"COMMA", u"INTEGER_CONSTANT", 
            u"IDENTIFIER", u"MODEL_END", u"STRING_CONSTANT", u"TERMS_BEGIN", 
            u"TERMS_END", u"WHITE_SPACE" ]

    ruleNames = [ u"START", u"COST_LABEL", u"ANY", u"IGNORE", u"AT", u"INTEGER", 
                  u"NEW_LINE", u"BLANK_SPACE", u"COMMA", u"INTEGER_CONSTANT", 
                  u"IDENTIFIER", u"MODEL_END", u"STRING_CONSTANT", u"TERMS_BEGIN", 
                  u"TERMS_END", u"WHITE_SPACE", u"INT", u"NL", u"WS" ]

    grammarFileName = u"DLV2Lexer.g4"

    def __init__(self, input=None, output=sys.stdout):
        super(DLV2Lexer, self).__init__(input, output=output)
        self.checkVersion("4.7")
        self._interp = LexerATNSimulator(self, self.atn, self.decisionsToDFA, PredictionContextCache())
        self._actions = None
        self._predicates = None


