class PDDLProgramType(object):
    """Enumeration class that contains two constants representing the
    types of a PDDL program."""
    PROBLEM = 0
    DOMAIN = 1
